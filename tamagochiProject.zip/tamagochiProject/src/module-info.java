/**
 * 
 */
/**
 * 
 */
module tamagochiProject {
}