package tamagochiProject;

import java.util.Scanner;

public class Main {
	// Set the userinput to false
    private static boolean userInputReceived = false;

    public static void main(String[] args) {
    	//create scanner
        Scanner scanner = new Scanner(System.in);
        //from my tamagochiProgram Class create a new tamagochi program
        tamagochiProgram pet = new tamagochiProgram();

        //asking user what is the name of their pet
        System.out.print("What will be the name of your pet: ");
        //create a user input for pet's name
        String petName = scanner.nextLine();
        //set the petname and use it multiple times
        pet.setPetName(petName);

        // loop the thread until the 0 health is reached
        while (pet.getHealth() > 0) {
            userInputReceived = false;

            //create a thread for sleep conditions
            Thread userInputThread = new Thread(() -> {
            	//i user try and catch to give me the specific error of my program
                try {
                	//set the thread to 5 seconds so if the user doesn't put any actions in 5 seconds, the health will be deducted
                    Thread.sleep(5000);
                    if (!userInputReceived) {
                        System.out.println("Time's up! " + pet.getPetName() + "'s health is deducted.");
                        pet.decreaseHealth();
                        System.out.println(pet.getPetName() + "'s health: " + pet.getHealth()); // Display health
                        pet.setStatus(pet.randomStatus()); // Update status
                    }
                } catch (InterruptedException e) {
                    // I will live it empty
                }
            });

            // start the thread
            userInputThread.start();

            //create a table where the emotions will set randomly
            System.out.println("--------------------------------------------------");
            System.out.println("| " + pet.getPetName() + " |   " + pet.getStatus());
            System.out.println("--------------------------------------------------");
            System.out.println("| Select option: 1 = eat, 2 = play, 3 = sleep.");
            System.out.println("--------------------------------------------------");

            //setting up the input for giving order to emotions
            String input = scanner.nextLine();
            userInputReceived = true;

            //interrupt the thread to stop interval
            userInputThread.interrupt();

            // check if the input do not matched the 3 numbers
            if (!input.matches("[1-3]")) {
                System.out.println("| Wrong input! " + pet.getPetName() + "'s health is deducted.");
                pet.decreaseHealth();
                System.out.println(pet.getPetName() + "'s health: " + pet.getHealth()); // Display health
            } else {
                int choice = Integer.parseInt(input);
                // i us switch case instead of if else to optimize the code
                switch (choice) {
                    case 1:
                    	// check if the user input chosen the right solution
                        if (pet.getStatus().equals("Hungry")) {
                            pet.eat();
                        } else {
                            System.out.println("| Wrong choice! " + pet.getPetName() + "'s health is deducted.");
                            pet.decreaseHealth();
                            System.out.println(pet.getPetName() + "'s health: " + pet.getHealth()); // Display health
                        }
                        break;
                    case 2:
                    	// check if the user input chosen the right solution
                        pet.play();
                        break;
                    case 3:
                    	// check if the user input chosen the right solution
                        if (pet.getStatus().equals("Sleepy")) {
                            pet.sleep();
                        } else {
                            System.out.println("| Wrong choice! " + pet.getPetName() + "'s health is deducted.");
                            pet.decreaseHealth();
                            System.out.println(pet.getPetName() + "'s health: " + pet.getHealth()); // Display health
                        }
                        break;
                }
            }

            // create a random pet status
            pet.setStatus(pet.randomStatus()); // Update status

            // set the interval of the emotion of 5 seconds
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // return a game over output of the health becaomes 0
        System.out.println("Game over! " + pet.getPetName() + "'s health reached 0.");
    }
}
