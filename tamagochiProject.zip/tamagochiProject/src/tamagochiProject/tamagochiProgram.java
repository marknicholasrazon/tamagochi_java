package tamagochiProject;

import java.util.Random;

public class tamagochiProgram {

	// defining private variables
    private int health;
    private String status;
    private Random rand;
    private String petName;

    // class that holds tamagochi's data
    public tamagochiProgram() {
        health = 20;
        rand = new Random();
        status = randomStatus();
    }

    // class for returning the current health
    public int getHealth() {
        return health;
    }

    // class for returning the current status
    public String getStatus() {
        return status;
    }

    // setting up a random status
    public void setStatus(String status) {
        this.status = status;
    }

    //setting up the pet's name
    public void setPetName(String name) {
        this.petName = name;
    }

    // fetching the pet's name
    public String getPetName() {
        return petName;
    }

    // class for eating output
    public void eat() {
        System.out.println(petName + " is eating. Yum!");
        this.health += 2;
    }

    // class for playing output
    public void play() {
        System.out.println(petName + " is playing. So much fun!");
        this.health += 2;
    }

    // class for sleeping output
    public void sleep() {
        System.out.println(petName + " is sleeping. Zzz...");
        this.health += 2;
    }

    // deduction of health
    public void decreaseHealth() {
        this.health--;
    }

    //creating a random status
    public String randomStatus() {
        int randomNum = rand.nextInt(3);
        if (randomNum == 0) {
            return "Hungry";
        } else if (randomNum == 1) {
            return "Sad";
        } else {
            return "Sleepy";
        }
    }
}
